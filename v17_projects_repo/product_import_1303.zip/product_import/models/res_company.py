from odoo import models, fields, api
import xlrd
from odoo.modules.module import get_module_path
import base64
import requests


class ResCompany(models.Model):
    _inherit = 'res.company'


    def import_products(self):
        print("\n\n\nimport_products---------------------------------")
        self.import_product_template()
        # self.import_product_attribute()
        return True

    def import_product_template(self):
        print("\n\n\nimport_product_template-----------------------------------------")
        print("\n\n\nimport_product_attribute----------------------------------")
        module_path = get_module_path('product_import')
        print("module_path-----------------------", module_path)
        file_path = module_path + '/script/Customer_Product_Download _Ross.xlsx'
        print("file_path----------------------", file_path)
        wb = xlrd.open_workbook(file_path)
        print("wb------>>>>>>>>>.--------------------", wb)
        sheet_name = wb.sheet_by_name('AnthonyWebstoreResults')
        print("sheet_name--------------------", sheet_name)
        product_variant_lst = []
        product_attribute = {}
        attr_dict = {}
        att_dict = {}
        # for item in range(1, sheet_name.nrows):
        #     product_tem_name = sheet_name.cell_value(item, 0)
        #     attribute_1 = sheet_name.cell_value(item, 2)
        #     option_value_1 = sheet_name.cell_value(item, 3)
        #     if product_tem_name not in att_dict:
        #         att_dict[product_tem_name] = [{
        #             attribute_1: [product_attribute.get(attribute_1).get(str(option_value_1))],
        #         }]
        #     else:
        #         if attribute_1 in att_dict[product_tem_name][0] and \
        #                 product_attribute.get(attribute_1).get(str(option_value_1)) not in \
        #                 att_dict[product_tem_name][0][attribute_1]:
        #             att_dict[product_tem_name][0][attribute_1].append(
        #                 product_attribute.get(attribute_1).get(str(option_value_1)))







        for prd_attr in self.env['product.attribute'].search([]):
            product_attribute.update({prd_attr.name: prd_attr.id})

        value_list = []
        for items in range(2, sheet_name.nrows):
            print("\n 4---------------------------", sheet_name.cell_value(items, 4))

            # image_url = sheet_name.cell_value(items, 15)
            # print("url-----------------------", image_url)
            # response = requests.get(image_url)
            # print("response--------------------------------------", response)
            # image_content = response.content
            # print("image_content----------------------------", image_content)
            # if sheet_name.cell_value(items, 4):
            #     print("True------------111111111--------------", sheet_name.cell_value(items, 2))
            #     product_template_vals = {
            #         'default_code': sheet_name.cell_value(items, 0),
            #         'name': sheet_name.cell_value(items, 5),
            #         'barcode': sheet_name.cell_value(items, 12),
            #         'description': sheet_name.cell_value(items, 16),
            #         'description_sale': sheet_name.cell_value(items, 6),
            #         # 'image_1920': base64.b64encode(image_content)
            #     }
            #     print("product_template_vals---------------", product_template_vals)
            #     self.env['product.template'].create(product_template_vals)
            #
            # product_tem_name = sheet_name.cell_value(items, 0)
            # print("product_tem_name--------------------------",product_tem_name)
            attribute_1 = sheet_name.cell_value(items, 2)
            # if attribute_1 in product_attribute:
            #     prd_attr_id = product_attribute.get(attribute_1)
            # else:
            #     prd_attr_id = self.env['product.attribute'].create({'name': attribute_1}).id
            #     product_attribute.update({attribute_1: prd_attr_id})
            #     print("product_attribute----------attrbute----------------------", product_attribute)
            # att_id = self.env['product.attribute'].search([('name', '=', attribute_1)])
            # print("att_id-------------------------", att_id)
            option_value_1 = sheet_name.cell_value(items, 3)
            # if option_value_1:
            #     if option_value_1 in attr_dict:
            #         value_id = attr_dict.get(option_value_1)
            #     else:
            #         value_id = self.env['product.attribute.value'].create({'name': option_value_1,
            #                                                                'attribute_id': att_id.id}).id
            #         attr_dict.update({option_value_1: value_id})
            # # varient_value_lst = []
            # # varint_value_dict = {}
            product_template = self.env['product.template'].search([('default_code', '=', sheet_name.cell_value(items, 0))], limit=1)
            # print("product_template---------------------------",product_template)

            att_id = self.env['product.attribute'].search([('name', '=', attribute_1)])
            # print("att_id-------------------------",att_id)
            attr_value = self.env['product.attribute.value'].search([('name', '=', str(option_value_1))])
            # print("attr_value-------------------------", attr_value)

            if product_template.default_code == sheet_name.cell_value(items, 0):
                print("oooooooooooooooo")
                print("sheet_name.cell_value(items, 4)--------", sheet_name.cell_value(items, 4))
                if sheet_name.cell_value(items, 3):
                    value_list.append(attr_value.id)
                if sheet_name.cell_value(items, 4) and value_list != []:
                    print("*****************************************************************************")
                    print("value_list/////////", value_list)
                    product_template.write({
                        'attribute_line_ids': [
                            (0, 0, {
                                'attribute_id': att_id.id,
                                'value_ids': [(6, 0, value_list)]
                            })
                        ]
                    })
                    value_list.clear()
            # print("\n value_list++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", value_list)





        # print("value_list---->>>>>>>>>>>>>>for>>>>>>>>>>>>>>>>>>>>---------------",value_list)


            # if attr_value:
            #     value_lst = []
            #     for attr in product_template.attribute_line_ids:
            #         print("\n attr--------------", attr)
            #         if attr.attribute_id == att_id:
            #             print("if======================")
            #
            #     fd
            #     product_template.write({
            #         'attribute_line_ids': [
            #             (0, 0, {
            #                 'attribute_id': att_id.id,
            #                 'value_ids': value_ids
            #             })
            #         ]
            #     })
        print("value_list---->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>---------------",value_list)



    # def import_product_template(self):
    #     print("\n\n\nimport_product_template=========================")
    #     module_path = get_module_path('product_import')
    #     print("module_path-----------------------",module_path)
    #     module_path += '/script/Customer Product Download - Ross.xlsx'
    #     file_path = module_path + '/script/Customer Product Download - Ross.xlsx'
    #     print("file_path----------------------",file_path)
    #     wb = xlrd.open_workbook(file_path)
    #     print("wb------>>>>>>>>>.--------------------",wb)
    #     sheet_name = wb.sheet_by_name('AnthonyWebstoreResults')
    #     product_variant_lst = []
    #     product_attribute = {}
    #     for items in range(2, sheet_name.nrows):
    #         image_url = sheet_name.cell_value(items, 13)
    #         print("url-----------------------",image_url)
    #         response = requests.get(image_url)
    #         print("response--------------------------------------",response)
    #         image_content = response.content
    #         print("image_content----------------------------", image_content)
    #         if sheet_name.cell_value(items, 2):
    #             print("True------------111111111--------------",sheet_name.cell_value(items, 2))
    #             product_template_vals = {
    #                 'default_code': sheet_name.cell_value(items, 0),
    #                 'name': sheet_name.cell_value(items, 3),
    #                 'barcode': sheet_name.cell_value(items, 10),
    #                 'description': sheet_name.cell_value(items, 14),
    #                 'description_sale': sheet_name.cell_value(items, 4),
    #                 'image_1920': base64.b64encode(image_content)
    #             }
    #             print("product_template_vals---------------",product_template_vals)
    #             self.env['product.template'].create(product_template_vals)
    #     #     product_template = self.env['product.template'].search([('default_code', '=', sheet_name.cell_value(items, 0))], limit=1)
    #     #     print("product_obj-------------------------",product_template)
    #     #     print("sheet_name.cell_value(items, 0)-------------------------",sheet_name.cell_value(items, 0))
    #     #     if product_template and sheet_name.cell_value(items, 1):
    #     #         print("True-------------222222222222-------------------------")
    #     #         product_varient_vals = {
    #     #             'product_tmpl_id': product_template.id,
    #     #             'default_code': sheet_name.cell_value(items, 1),
    #     #             'name': sheet_name.cell_value(items, 3),
    #     #             'barcode': sheet_name.cell_value(items, 10),
    #     #             'description': sheet_name.cell_value(items, 14),
    #     #             'image_variant_1920': base64.b64encode(image_content)
    #     #         }
    #     #         product_variant_lst.append(product_varient_vals)
    #     # a = self.env['product.product'].create(product_variant_lst)
    #     # print("product_varient_vals------------------",a)
    #
    # def import_product_attribute(self):
    #     print("\n\n\nimport_product_attribute----------------------------------")
    #     module_path = get_module_path('product_import')
    #     print("module_path-----------------------", module_path)
    #     file_path = module_path + '/script/Customer_Product_Download _Ross.xlsx'
    #     print("file_path----------------------", file_path)
    #     wb = xlrd.open_workbook(file_path)
    #     print("wb------>>>>>>>>>.--------------------", wb)
    #     sheet_name = wb.sheet_by_name('AnthonyWebstoreResults')
    #     print("sheet_name--------------------",sheet_name)
    #     product_attribute = {}
    #     attr_dict = {}
    #     prod_dict = []
    #     for prd_attr in self.env['product.attribute'].search([]):
    #         product_attribute.update({prd_attr.name: prd_attr.id})
    #
    #     for item in range(2, sheet_name.nrows):
    #         print("for 22222222222222222222222222222222222222222222222222222222")
    #         product_tem_code = sheet_name.cell_value(item, 0)
    #         # print("product_tem_name--------------------------",product_tem_name)
    #         attribute_1 = sheet_name.cell_value(item, 2)
    #         # print("attribute_1--------------------------",attribute_1)
    #         option_value_1 = sheet_name.cell_value(item, 3)
    #
    #         if attribute_1 in product_attribute:
    #             prd_attr_id = product_attribute.get(attribute_1)
    #         else:
    #             prd_attr_id = self.env['product.attribute'].create({'name': attribute_1}).id
    #             product_attribute.update({attribute_1: prd_attr_id})
    #             print("product_attribute----------attrbute----------------------",product_attribute)
    #         att_id = self.env['product.attribute'].search([('name', '=',attribute_1)])
    #         print("att_id-------------------------",att_id)


            # if option_value_1 in attr_dict:
            #     value_id = attr_dict.get(option_value_1)
            # else:
            #     value_id = self.env['product.attribute.value'].create({'name': option_value_1,
            #                                                            'attribute_id': att_id.id}).id
            #     attr_dict.update({option_value_1: value_id})


            # prod_id = False
            # if product_tem_code not in prod_dict:
            #     temp_dict = {
            #         'name': sheet_name.cell_value(item, 5),
            #         'default_code': sheet_name.cell_value(item, 0),
            #         'barcode': sheet_name.cell_value(item, 12),
            #         'sale_ok': True,
            #         'purchase_ok': True,
            #     }
            #     prod_id = self.env['product.template'].create(temp_dict)
            #     prod = self.env['product.template'].browse(prod_id).id
            #     prod_dict.append(prod.name)
                # print("prod_dict--------->name---------------------",prod_dict)
            # if prod_id:
            #     print("ifffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff")
            #     for att in product_attribute.get(attribute_1):
            #         print("forr-----****************************************************************************************")
            # if prod_id:
            #     print("true----------------")
            #     print("product_attribute-----------------------",product_attribute.get(attribute_1))

                # for att in product_attribute.get(product_tem_name):
                # for att in product_attribute.get(product_tem_name):
                #     print("true**********************************************************")
                    # if attribute_1 in att:
                    #     prod.write({
                    #         'attribute_line_ids': [
                    #             (0, 0, {
                    #                 'attribute_id': 1,
                    #                 'value_ids': [(6, 0, att.get(attribute_1))]
                    #             })
                    #         ]
                    #     })
#













